======================================================================
    About Origin Viewer
======================================================================

Origin Viewer is a free software application created by OriginLab
Corporation for viewing Origin Project (.OPJ) and Window (.OGG,
.OGW, .OGM) files.  Origin Viewer is built on a limited version of
Origin and is compatible with all versions of Origin files.

Uses of the Origin Viewer for any other purposes without the express
written permission of OriginLab Corporation is prohibited.

OriginLab Corporation has made its best efforts to insure that the
software is correct.  OriginLab makes no warranties, either expressed
or implied as to the completeness, usability and correctness of this
software.  By using this software, it is implied that the user
understands and accepts these conditions.


======================================================================
    Origin Viewer Limitations
======================================================================

The following limitations exist in the current version:

1. When viewing Origin Project (.OPJ) files that contain Excel 
worksheets, the Excel worksheets as well as any graphs created from
the data in those worksheets cannot be viewed.

2. There is a limitation in displaying worksheets with very large
datasets. This is related to MSFlexGrid which has memory limitations. 

Please note that these limitations exist only in the Viewer.
The Origin software itself does not have these limitations.


======================================================================
    Origin Viewer Terms of Use
======================================================================

Please see licensing agreement text that is presented at time 
of installation.


======================================================================
    Notes for Origin Viewer Users
======================================================================

----------
File Menu:
----------
Use the "File|Open" menu item to open an existing Origin File.
The "Files of type" drop-down menu allows you to select and 
import Origin Project (OPJ), Origin Graph (OGG), Origin 
Worksheet (OGW) or Origin Matrix (OGM) files.

Recently opened files will be listed under this menu.

The "Open for Editing..." menu item launches Origin application,
if installed on the machine, with the file currently open in the 
viewer.

The "Close" menu item closes the currently open file.

The "Exit" menu item closes the application.

Note that you can open files by drag-and-drop onto the Viewer 
icon on the desktop. If multiple files are dropped then 
multiple instances of the Viewer will be launched. 

----------
Edit Menu:
----------
The Edit Menu can be used to copy data from Worksheet or Matrix, 
text content of Notes windows, and static images of Graphs, 
to other applications.

When Worksheet or Matrix data is displayed in the Viewer, there 
are two choices for copying the data:

The "Edit|Copy" menu item will copy the data as displayed in the 
view window. 

The "Edit|Copy Full Precision" menu item will copy all numeric 
data with full precision. Note that this applies only to columns 
set as numeric in the OPJ file and does not affect other column 
types such as Date, Time etc.

There is also an "Edit|Select All" menu item to select all the
data displayed for copying.

When a Graph is displayed in the Viewer, the "Edit|Copy" menu 
command copies the graph image in EMF format to the clipboard.

Notes window content is copied as ASCII text.

----------
View Menu:
----------
The "View|Show Results Log" menu command turns on/off the display 
of Results Log text. When this option is set to show Results Log, 
one can click on the main folder and/or any subfolder in the tree 
on the left panel and view the corresponding Results Log content 
for that subfolder in the right view panel.

The "View|Include Results from Subfolder" menu command determines 
whether Result Log entries pertaining to subfolders should be shown 
when user clicks at any folder level in the tree on the left panel.

Note that text from the Results Log that is displayed on the 
right panel can be copied by simply selecting desired text and 
then using the right-click context menu.

----------
Help Menu:
----------
The Help menu provides a link to the OriginLab website, a 
Help|About" dialog, and a menu item to open this readme file.


======================================================================
    Running Origin Viewer from a USB Drive
======================================================================

Once the Viewer has been installed, it can be distributed by copying
files onto another computer or onto a USB drive.

You could, for example, copy the Viewer files and a collection of
OPJ files onto a USB drive and then run the viewer from the USB
drive on another computer without having to install the Viewer
on that computer.

The files needed to copy from your Viewer installation are:

    oc3dmin.dll
    ocUtils.dll
    ogridmin.dll
    okMinV.dll
    okUtilMin80.dll
    omocavcmin.dll
    OPack.dll
    otextmin.dll
    Outl60min.dll
    OrgView.exe

    LFCMP14N.DLL
    LFPNG14N.DLL
    LFTIF14N.DLL
    LTDIS14N.DLL
    LTFIL14N.DLL
    LTIMG14N.DLL
    LTKRN14N.DLL

If you run the copied Viewer on another computer and get an
error message about any of the following files:

    MSFLXGRD.ocx
    MSCOMCTL.ocx
    COMDLG32.ocx

then you will first need to run the Viewer installation on that 
computer to update these files. Then you will be able to run the 
Viewer from a copy, such as from a USB drive.
