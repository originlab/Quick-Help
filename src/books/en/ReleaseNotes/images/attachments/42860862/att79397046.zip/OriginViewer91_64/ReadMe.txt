======================================================================
    About Origin Viewer 9.1
======================================================================

Origin Viewer is a free software application created by OriginLab
Corporation for viewing Origin Project (.OPJ) and Window (.OGG,
.OGW, .OGM) files.  Origin Viewer is built on a limited version of
Origin and is compatible with all versions of Origin files.

Uses of the Origin Viewer for any other purposes without the express
written permission of OriginLab Corporation is prohibited.

OriginLab Corporation has made its best efforts to insure that the
software is correct.  OriginLab makes no warranties, either expressed
or implied as to the completeness, usability and correctness of this
software.  By using this software, it is implied that the user
understands and accepts these conditions.

There is no installation required.  You may copy the OriginView9.exe
or OriginView9_64.exe to any location and run it from there.


======================================================================
    Origin Viewer Limitations
======================================================================

The following limitations exist in the current version:

1. When viewing Origin Project (.OPJ) files that contain Excel 
worksheets, the Excel worksheets as well as any graphs created from
the data in those worksheets cannot be viewed.

2. Matrix containing images that were not converted to data will not
be displayed without the appropriate OriginViewerImagePack files.
Contact OriginLab for a copy of the OriginViewerImagePack files.

3. The Viewer does not support display of MathType equation objects.

Please note that these limitations exist only in the Viewer.
The Origin software itself does not have these limitations.


======================================================================
    Origin Viewer Terms of Use
======================================================================

Please see the licensing agreement text file (OriginViewerEULA.txt)
that is distributed with the Origin Viewer for terms of use.
